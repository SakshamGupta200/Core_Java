package Swing;

import javax.swing.*;

public class Swing2 {
    private JButton button1;
    private JPanel panel1;
}
