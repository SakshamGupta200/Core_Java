package Swing;

import javax.swing.*;
import java.awt.*;

public class Puzzle {
    Label l=new Label();
    private JPanel panel1;
    private JButton a1Button;

    private JButton a2Button;
    private JButton a3Button;
    private JButton a4Button1;
    private JButton a5Button1;
    private JButton a6Button1;
    private JButton a7Button1;
    private JButton a8Button1;
    private JButton a9Button1;
    private JButton a10Button1;
    private JButton a11Button1;
    private JButton a12Button1;
    private JButton a13Button1;
    private JButton a14Button1;
    private JButton a15Button;
    private JButton button1;
    private JButton button2;

    public static void main(String[] args) {

    }
}
